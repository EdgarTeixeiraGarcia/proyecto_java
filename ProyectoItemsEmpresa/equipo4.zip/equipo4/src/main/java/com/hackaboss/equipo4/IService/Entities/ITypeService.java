package com.hackaboss.equipo4.IService.Entities;

import com.hackaboss.equipo4.Entity.Entities.Type;
import com.hackaboss.equipo4.IService.Component.IBaseService;


public interface ITypeService extends IBaseService<Type> {
}
