package com.hackaboss.equipo4.DTO.Component;

public interface IGenericDTO {
    Long getId();
    Boolean getActive();
}
