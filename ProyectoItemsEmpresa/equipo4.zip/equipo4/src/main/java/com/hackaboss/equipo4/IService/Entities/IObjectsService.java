package com.hackaboss.equipo4.IService.Entities;

import com.hackaboss.equipo4.Entity.Entities.Objects;
import com.hackaboss.equipo4.IService.Component.IBaseService;


public interface IObjectsService extends IBaseService<Objects> {
}
