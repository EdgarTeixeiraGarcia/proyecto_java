package grupo4.proyecto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackABossProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackABossProyectoApplication.class, args);
	}

}
