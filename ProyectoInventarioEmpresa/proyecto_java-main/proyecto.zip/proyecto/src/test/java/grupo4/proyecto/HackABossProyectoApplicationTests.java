package grupo4.proyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackABossProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
