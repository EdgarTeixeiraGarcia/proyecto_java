package com.hackaboss.equipo4.DTO.Entities;

import com.hackaboss.equipo4.DTO.Component.IGenericDTO;

public interface ITypeDTO extends IGenericDTO {
    String getName();
}