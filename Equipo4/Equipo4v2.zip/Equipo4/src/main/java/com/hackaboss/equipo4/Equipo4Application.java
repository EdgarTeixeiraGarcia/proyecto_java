package com.hackaboss.equipo4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Equipo4Application {

	public static void main(String[] args) {
		SpringApplication.run(Equipo4Application.class, args);
	}

}
