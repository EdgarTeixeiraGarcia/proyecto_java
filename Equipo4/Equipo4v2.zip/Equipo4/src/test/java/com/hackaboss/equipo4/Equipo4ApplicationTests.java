package com.hackaboss.equipo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Equipo4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
